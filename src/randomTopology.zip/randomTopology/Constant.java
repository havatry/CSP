package randomTopology;

/**
 * 
 * OverView:
 *		ͨ��������XMLHelp������ȡsetting.xml�����ļ������г���
 *		���庬��ο�setting.xml��˵��
 */
public class Constant {
	// �ֶ����µı���
	public static int WriteFile_TimeFor = 1;
	public static int TimeForTest = 1;

	// ������µı���
	public static int numNodes = Integer.parseInt(XMLHelper.getValue("//allInfo/node/number"));
	public static double gama = Double.parseDouble(XMLHelper.getValue("//allInfo/test/gama"));
	public static double MD = Double.parseDouble(XMLHelper.getValue("//allInfo/test/md"));

	// �������
	public static int group = Integer.parseInt(XMLHelper.getValue("//allInfo/input/group"));
	public static int copy = Integer.parseInt(XMLHelper.getValue("//allInfo/input/copy"));
	public static int step = Integer.parseInt(XMLHelper.getValue("//allInfo/input/step"));

	// ����
	public static final int W = Integer.parseInt(XMLHelper.getValue("//allInfo/node/area"));
	public static final double coreProbility = Double.parseDouble(XMLHelper.getValue("//allInfo/node/coreProbility"));
	public static final double coreToCoreProbility = Double
			.parseDouble(XMLHelper.getValue("//allInfo/node/coreToCoreProbility"));
	public static final double coreToNormalProbility = Double
			.parseDouble(XMLHelper.getValue("//allInfo/node/coreToNormalProbility"));
	public static final String basePath = XMLHelper.getValue("//allInfo/file/@basePath");
	public static final String idFile = basePath + XMLHelper.getValue("//allInfo/file/idFile");
	public static final String edgeFile = basePath + XMLHelper.getValue("allInfo/file/edgeFile");
	public static final String nodeFile = basePath + XMLHelper.getValue("allInfo/file/nodeFile");
	public static final String coreNodeFile = basePath + XMLHelper.getValue("//allInfo/file/coreNodeFile");
	public static final boolean debug = Boolean.parseBoolean(XMLHelper.getValue("//allInfo/test/debug"));
	public static final int MAX_VALUE = Integer
			.parseInt(XMLHelper.getValue("//allInfo/program/notExistsEdgeForValueOfYen"));
	public static final double esp = Double.parseDouble(XMLHelper.getValue("//allInfo/input/esp"));// LARAC�Ͷ��ַ�����
	public static final int MIN = Integer.parseInt(XMLHelper.getValue("//allInfo/program/notExistsPathForValue"));
	public static final double ExistsPathForValue = Double
			.parseDouble(XMLHelper.getValue("//allInfo/program/ExistsPathForValue"));
	public static final int notExistsPathForYenKValue = Integer
			.parseInt(XMLHelper.getValue("//allInfo/program/notExistsPathForYenKValue"));
	public static final int notExistsPathForValue = Integer
			.parseInt(XMLHelper.getValue("//allInfo/program/notExistsPathForValue"));
}
